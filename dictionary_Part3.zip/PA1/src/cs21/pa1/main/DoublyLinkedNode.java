/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 * PA1 Part3
 */
package cs21.pa1.main;

public class DoublyLinkedNode<T>{
	private T data;
	private DoublyLinkedNode<T> next;
	private DoublyLinkedNode<T> prev;
	
	public DoublyLinkedNode(T data) {
		this.data=data;
		this.next=null;
		this.prev=null;
	}
	public T getData(){//O(1)
		return data;
	}
	public void setNext(DoublyLinkedNode<T> nextNode){//O(1)
		this.next=nextNode;
	}
	public void setPrev(DoublyLinkedNode<T> prevNode){//O(1)
		this.prev=prevNode;
	}
	public DoublyLinkedNode<T> getNext(){//O(1)
		return next;
	}
	public DoublyLinkedNode<T> getPrev(){//O(1)
		return prev;
	}
	public String toString(){//O(1)
		return data.toString();
	}
}