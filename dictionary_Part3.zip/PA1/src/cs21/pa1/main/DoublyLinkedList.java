/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 * PA1 Part3
 */
package cs21.pa1.main;

public class DoublyLinkedList<T>{
	private DoublyLinkedNode<T> head;
	private int size;
	
	public DoublyLinkedList(){
		this.head=null;
		this.size=0;
	}
	public DoublyLinkedNode<T> getHead(){//O(1)
		return head;
	}
	
	/**
	 * insert a new node at the end of the linkedlist
	 * if the list is empty, the new node will be the head
	 * Running time is O(n)
	 * @param data
	 */
	public void insert(T data){
		DoublyLinkedNode<T> newNode=new DoublyLinkedNode<T>(data);
		DoublyLinkedNode<T> curr=head;
		if(size==0) {
			head=newNode;
		}else {
			while(curr.getNext()!=null) {
				curr=curr.getNext();
			}
			curr.setNext(newNode);
			newNode.setPrev(curr);
		}
		size++;
	}
	
	/**
	 * Running time O(n)
	 * insert object at the specific index into the doublylinkedlist
	 * @param data
	 * @param index
	 * @throws Exception
	 */
	public void insert(T data, int index) throws Exception {
		DoublyLinkedNode<T> newNode=new DoublyLinkedNode<T>(data);
		DoublyLinkedNode<T> curr=head;
		if(size==0) {
			head=newNode;
			size++;
		}else if(index==0) {
			newNode.setNext(curr);
			curr.setPrev(newNode);
			head=newNode;
			size++;
		}else if(index<=size){
			int i=1;
			while(curr!=null) {
				if(i==index) {
					newNode.setNext(curr.getNext());
					curr.getNext().setPrev(newNode);
					curr.setNext(newNode);
					newNode.setPrev(curr);
					size++;
				}
				curr = curr.getNext();
				i++;
			}			
		}else {
			System.out.println("index out of bound");
		}
	}
	
	/**
	 * Running time is O(n)
	 * @return last node in the list
	 */
	public DoublyLinkedNode<T> remove(){
		DoublyLinkedNode<T> curr=head;
		DoublyLinkedNode<T> next = head.getNext();
		while(next.getNext()!=null) {
			curr = next;
			next = next.getNext();
		}
		curr.setNext(null);
		return next;
	}
	
	/**
	 * Running time is O(n)
	 * remove the first object pass in the parameter in the doublylinkedlist
	 * @param data
	 * @throws Exception
	 */
	public void remove(T data) throws Exception{
		if (size==0) {
			System.out.println("error: list is empty");
		}else {
			DoublyLinkedNode<T> curr=head;
			DoublyLinkedNode<T> next=curr.getNext();
			if (head.getData().equals(data)){
				head=curr.getNext();
				curr.getNext().setPrev(null);
				size--;
			}else{
				while(next!=null) {
					if(next.getData().equals(data)) {
						curr.setNext(next.getNext());
						if(next.getNext()!=null) {
							next.getNext().setPrev(curr);
						}
						next = null;
						size--;
					}else {
						curr = next;
						next = next.getNext();
					}
				}		
			}
		}
	}
	
	/**
	 * Running time is O(n)
	 * remove and return the node at specific index
	 * @param index
	 * @return node at the specific index 
	 * @throws Exception
	 */
	public DoublyLinkedNode<T> remove(int index) throws Exception {
		if(size == 0) {
			System.out.println("error:list is empty");
		}else {
			DoublyLinkedNode<T> remove;
			DoublyLinkedNode<T> curr=head;
			DoublyLinkedNode<T> next=curr.getNext();
			if(index==0) {
				head=next;
				next.setPrev(null);
				remove=curr;
				size--;
				return remove;
			}else if(index<size) {
				int i=1;
				while(next!=null) {
					if(i==index) {
						curr.setNext(next.getNext());
						next.getNext().setPrev(curr);
						size--;
						remove = next;
						return remove;
					}
					i++;
					curr = next;
					next = next.getNext();
				}
			}else {
				throw new Exception("index out of bound");
			}
		}
		return null;
	}
	
	public int size(){//O(1)
		return size;
	}
	public String toString(){//O(n)
		if (size==0){
			return "empty";
		}
		DoublyLinkedNode<T> curr=head;
		String s=head.toString();
		while (curr.getNext()!=null){
			curr=curr.getNext();
			s=s+" "+curr.toString();
		}
		return s;
	}
}