/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 * PA1 Part3
 */
package cs21.pa1.main;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class GameForPart3{
	public static WordListForPart3 dictionary;
	public static DoublyLinkedList<People> people = new DoublyLinkedList<People>();

	public static void main(String[] args) throws Exception {
		//set up the game and ask for an input sentence
		setUp();
		SinglyLinkedList<String> sentence = new SinglyLinkedList<String>();
		//check for valid input sentence
		while(sentence.size()==0) {
			System.out.println("Please enter a sentence to start:");
			Scanner scanner = new Scanner(new Scanner(System.in).nextLine());
			String word;
			while(scanner.hasNext()){
				word = scanner.next();
				sentence.insert(word);
			}
		}
		DoublyLinkedNode<People> p = people.getHead();
		p.getData().setSpeak(sentence);
		while(p.getNext()!=null) {
			System.out.println(p.getData().getName()+" says "+"\""+p.getData().getSpeak().toString()+"\""+" to "+p.getNext().getData().getName());
			hearingSentence(p.getNext(),p.getData().getSpeak());//O(m)
			System.out.println(p.getNext().getData().getName()+" hears "+"\""+p.getNext().getData().getHeard()+"\"");
			//if the number of words misheard more than three, then ask the previous person to repeat
			//until fewer than three or return to randomly pick five words
			if(findMissing(p.getNext().getData().getHeard())>3) {
				p.getNext().getData().setSpeak(askToRepeat(p.getData().getSpeak(),p.getNext()));
			}
			p = p.getNext();
		}
		System.out.println(p.getData().getName()+" says "+"\""+p.getData().getSpeak().toString()+"\"");
	}
	
	/**
	 * set up the game to have five people playing the game and set up the dictionary
	 * @throws FileNotFoundException
	 */
	public static void setUp() throws FileNotFoundException {		
		People p1 = new People("person1");
		People p2 = new People("person2");
		People p3 = new People("person3");
		People p4 = new People("person4");
		People p5 = new People("person5");
		people.insert(p1);
		people.insert(p2);
		people.insert(p3);
		people.insert(p4);
		people.insert(p5);
		dictionary = new WordListForPart3();
	}
	
	/**
	 * Running time for this method is O(n)
	 * @param sentence spoken by the previous person
	 * @param current player
	 * @return sentence that current player will say
	 * @throws Exception
	 */
	public static SinglyLinkedList<String> askToRepeat(SinglyLinkedList<String> heard, DoublyLinkedNode<People> pNode) throws Exception{
		People curr = pNode.getData();
		People prev = pNode.getPrev().getData();
		int countOfRepeat = 0;
		//asking the previous person to repeat no more than five times
		while(countOfRepeat<5) {
			System.out.println(curr.getName()+" asks "+prev.getName()+" to repeat what they said.");
			System.out.println(prev.getName()+" says "+"\""+prev.getSpeak().toString()+"\""+" to "+curr.getName());
			countOfRepeat++;
			hearingSentence(pNode, heard);//O(n)
			System.out.println(curr.getName()+" hears "+"\""+curr.getHeard().toString()+"\"");
			if(findMissing(curr.getHeard())<=3) {
				return curr.getSpeak();
			}
		}
		//otherwise, randomly pick five words
		return dictionary.pickFive();
	}
	
	/**
	 * Running time for this method is O(n)
	 * @param pNode (current player)
	 * @param sentence (the sentence that this player need to hear)
	 * @throws Exception
	 */
	public static void hearingSentence(DoublyLinkedNode<People> pNode, SinglyLinkedList<String> sentence) throws Exception{
		SinglyLinkedList<String> hear = new SinglyLinkedList<String>(); 
		//need to new singlylinkedlist to store what next person speak 
		//avoid changing what previous person heard
		SinglyLinkedList<String> temp = new SinglyLinkedList<String>();
		SinglyLinkedNode<String> head = sentence.getHead();
		while(head!=null) {
			temp.insert(head.getData());
			head = head.getNext();
		}
		double check = pNode.getData().getListening()*pNode.getData().getSpeaking();
		SinglyLinkedNode<String> curr = sentence.getHead();
		int i=0;
		while(i<temp.size()) {
			//for each word in the sentence, check whether it will be misheard
			if(Math.random()>check) {
				String mishear = temp.remove(i).getData();
				hear.insert("___");
				//reinsert the word to avoid index out of bound exception
				temp.insert(mishear, i);
				String newWord = dictionary.search(mishear);
				//drop the word if can't find a new word in the word list
				if(newWord!=null) {
					temp.remove(i);
					temp.insert(newWord, i);
				}
			}else {
				hear.insert(curr.getData());
			}
			i++;
			curr = curr.getNext();
		}
		pNode.getData().setHeard(hear);
		pNode.getData().setSpeak(temp);
	}
	
	//count the number of word misheard in the sentence
	//running time is O(n)
	public static int findMissing(SinglyLinkedList<String> heard){
		int count =0;
		SinglyLinkedNode<String> curr = heard.getHead();
		while(curr!=null) {
			if(curr.getData().equals("___")) {
				count++;
			}
			curr = curr.getNext();
		}
		return count;
	}
}