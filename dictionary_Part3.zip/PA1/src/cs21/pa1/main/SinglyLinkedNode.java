/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 */
package cs21.pa1.main;

public class SinglyLinkedNode<T> {
	private T data;
	private SinglyLinkedNode<T> next;
	
	public SinglyLinkedNode(T data){//O(1)
		this.data=data;
		this.next=null;
	}
	public T getData(){//O(1)
		return data;
	}
	public void setNext(SinglyLinkedNode<T> nextNode){//O(1)
		this.next=nextNode;
	}
	public SinglyLinkedNode<T> getNext(){//O(1)
		return next;
	}
	public String toString(){//O(1)
		return data.toString();
	}
}