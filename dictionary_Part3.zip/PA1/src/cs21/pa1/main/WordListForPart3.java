package cs21.pa1.main;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WordListForPart3{
	public static final int WORD_FLEXIBILITY = 5;
	private SinglyLinkedList<SinglyLinkedList<String>> dictionary;
	
	/**
	 * constructor of Wordlist which stores the wordlist.txt into a dictionary
	 * which is a SinglyLinkedList of SinglyLinkedList of string stored in alphabetical order
	 * the running time of this method is O(n) where n is the size of the text
	 * @throws FileNotFoundException
	 */
	public WordListForPart3() throws FileNotFoundException {
		dictionary = new SinglyLinkedList<SinglyLinkedList<String>>();
		Scanner sc = new Scanner(new File(System.getProperty("user.dir")+"/wordlist.txt"));
		String check = "a";
		SinglyLinkedList<String> alphabet = new SinglyLinkedList<String>();
		while(sc.hasNextLine()) {
			String s = sc.nextLine();
			if((""+s.charAt(0)).equalsIgnoreCase(check)) {
				alphabet.insert(s);
			}else {
				//if the string starts with a new character
				//store the previous linkedlist of strings and initialize a new one 
				//to store new words start with this char
				dictionary.insert(alphabet);
				check = ""+s.charAt(0);
				alphabet = new SinglyLinkedList<String>();
				alphabet.insert(s);
			}
		}
		dictionary.insert(alphabet);//add the last list of word start with z into the dictionary
	}
	/**
	 * Running time for this method is O(n)
	 * method to search for a new word in the wordlist 
	 * @param word
	 * @return newWord
	 */
	public String search(String line) {
		String word = dropLetters(line);
		if(word.equals("")) {
			return null;
		}
		SinglyLinkedNode<SinglyLinkedList<String>> currList = dictionary.getHead();
		String firstOfLetter = currList.getData().getHead().getData();
		//go through the dictionary and get to the list with words starting with same character
		while(word.charAt(0)!=firstOfLetter.charAt(0) && currList.getNext()!=null) {//O(26)
			currList= currList.getNext();
			firstOfLetter = currList.getData().getHead().getData();
		}
		SinglyLinkedNode<String> currWord = currList.getData().getHead();
		//go through the list and return the first word with edit distance > 5
		while(currWord!=null) {//O(n) n = number of words starting with specific character
			String check = currWord.getData();
			if(editDistance(check,word)< WORD_FLEXIBILITY) {
				return check;
			}else {
				currWord = currWord.getNext();
			}
		}
		return null;
	}
	
	/**
	 * method to randomly pick 5 words from the wordlist and form a new sentence
	 * the running time is O(n)
	 * @return SinglyLinkedList of new sentence
	 */
	public SinglyLinkedList<String> pickFive(){
		int count = 0;
		boolean pick = false;
		SinglyLinkedList<String> newSentence = new SinglyLinkedList<String>();
		SinglyLinkedNode<SinglyLinkedList<String>> currList = dictionary.getHead();
		while(count<5 && currList!=null) {//O(26)
			//check whether the current list could have a word
			if(Math.random()>0.5) {
				//pick a word in the list then get out of the loop to search in other lists
				SinglyLinkedNode<String> currWord = currList.getData().getHead();
				while(count<5 && currWord!=null && !pick) {//O(n) n = number of words starting with specific character
					if(Math.random()>0.5) {
						newSentence.insert(currWord.getData());
						count++;
						pick = true;
					}
					currWord = currWord.getNext();
				}
			}
			currList = currList.getNext();
			pick = false;
		}
		return newSentence;
	}
	
	public int editDistance(String x, String y) {

	    // distance matrix to store subproblems
	    int[][] dist = new int[x.length() + 1][y.length() + 1];

	    // fill out all cells in matrix
	    // iterate through letters of first word
	    for (int i = 0; i <= x.length(); i++) {
	        // iterate through letters of second word
	        for (int j = 0; j <= y.length(); j++) {
	            // initialization
	            if (i == 0) {
	                dist[i][j] = j;
	            // initialization
	            } else if (j == 0) {
	                dist[i][j] = i;
	            // else fill out cell using Edit Distance algorithm – minimum of three possible paths
	                // path 1: from diagonal [i-1][j-1]:
	                        // a) if letters are the same, no additional cost
	                        // b) if letters different, add substitution cost (+1)
	                // paths 2 & 3: come from above or from left: add insertion/deletion cost (+1)
	            } else {
	                dist[i][j] = java.lang.Math.min(dist[i - 1][j - 1] + costOfSubstitution(x.charAt(i - 1), y.charAt(j - 1)),
	                        java.lang.Math.min(dist[i - 1][j] + 1, dist[i][j - 1] + 1));
	            }
	        }
	    }

	    // return solution to entire problem (stored in bottom right cell)
	    return dist[x.length()][y.length()];

	}

	// substitution cost (0 if same, 1 if different)
	public static int costOfSubstitution(char a, char b) {
	    return a == b ? 0 : 1;
	}
	/**
	 * method to find the minimum value 
	 * running time is constant O(1)
	 * @param x
	 * @param y
	 * @param z
	 * @return minimum value among three inputs
	 */
	public int findMin(int x,int y,int z) {
		int min = x;
		if (y<=min) {
			min=y;
		}
		if(z<=min) {
			min=z;
		}
		return min;
	}
	/**
	 * method to randomly drop up to three letters from the misheard word
	 * @param word
	 * @return
	 * running time for this method is O(n)
	 */
	public String dropLetters(String word) {
		int drop = 0;
		String newWord = "";
		for(int i=0;i<word.length();i++) {
			if(drop<=3 && Math.random()>0.5) {
				drop++;
			}else {
				newWord+=word.charAt(i);
			}
		}
		return newWord;
	}
	
	
}