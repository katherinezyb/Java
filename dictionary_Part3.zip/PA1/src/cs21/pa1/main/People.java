/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 * PA1 Part2
 */
package cs21.pa1.main;

public class People{
	private double SpeakingClarity;
	private double ListeningAbility;
	private SinglyLinkedList<String> heard;
	private SinglyLinkedList<String> speak;
	private String name;
	
	/**
	 * all methods of people class have running time O(1)
	 */
	public People(String name){
		SpeakingClarity = Math.random();
		ListeningAbility = Math.random();
		heard = new SinglyLinkedList<String>();
		speak = new SinglyLinkedList<String>();
		this.name = name;
	}
	public double getSpeaking() {
		return SpeakingClarity;
	}
	public double getListening() {
		return ListeningAbility;
	}
	public void setHeard(SinglyLinkedList<String> heard) {
		this.heard = heard;
	}
	public void setSpeak(SinglyLinkedList<String> speak) {
		this.speak = speak;
	}
	public SinglyLinkedList<String> getHeard(){
		return heard;
	}
	public SinglyLinkedList<String> getSpeak(){
		return speak;
	}
	public String getName() {
		return name;
	}
}