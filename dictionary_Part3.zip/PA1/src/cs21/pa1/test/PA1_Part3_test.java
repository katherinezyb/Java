package cs21.pa1.test;
import cs21.pa1.main.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

public class PA1_Part3_test{
	People p1,p2,p3,p4;
	DoublyLinkedList<People> dlink;
	
	@BeforeAll
	public static void setUp() {
		System.out.println("Hello!");
	}
	
	@BeforeEach
	public void beforeEach() throws Exception {
		p1 = new People("Amy");	
		p2 = new People("Bob");
		p3 = new People("Charlie");
		p4 = new People("Billy");
		dlink = new DoublyLinkedList<People>();
		dlink.insert(p1);
		dlink.insert(p2, 0);
		dlink.insert(p3);
	}
	
	@AfterAll
	public static void end() {
		System.out.println("Goodbye.");
	}
	
	@Test
	public void testDoulbyLinkedListInsert(){
		System.out.println("Checking insertion for Doublylinkedlist");
		assertEquals(p2,dlink.getHead().getData());
		System.out.println("Test passed!");
	}
	@Test
	public void testDoublyLinkedListRemove() throws Exception {
		System.out.println("Checking deletion for Doublylinkedlist");
		assertEquals(p3,dlink.remove().getData());
		dlink.insert(p3);
		dlink.insert(p4);
		dlink.remove(p1);
		assertEquals(p3,dlink.getHead().getNext().getData());
		assertEquals(p3,dlink.remove(1).getData());
		System.out.println("Test passed!");
	}
	@Test
	public void testSize() throws Exception {
		System.out.println("Checking size");
		assertEquals(3,dlink.size());
		dlink.insert(p1,2);
		assertEquals(4,dlink.size());
		System.out.println(" All tests passed!");
	}
	@Test 
	public void testPrevNext() {
		System.out.println("Checking previous and next");
		assertEquals("Amy",dlink.getHead().getNext().getData().getName());
		assertEquals("Bob",dlink.getHead().getNext().getPrev().getData().getName());
		System.out.println(" All tests passed!");
	}
}