/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 * PA1 Part2
 */
package cs21.pa1.main;

public class People{
	private double SpeakingClarity;
	private double ListeningAbility;
	private String name;
	
	/**
	 * all methods of people class have running time O(1)
	 */
	public People(String name){
		SpeakingClarity = Math.random();
		ListeningAbility = Math.random();
		this.name = name;
	}
	public double getSpeaking() {
		return SpeakingClarity;
	}
	public double getListening() {
		return ListeningAbility;
	}
	public String getName() {
		return name;
	}
}