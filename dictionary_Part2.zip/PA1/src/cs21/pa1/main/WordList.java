/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 * PA1 Part2
 */
package cs21.pa1.main;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WordList{
	public static final int WORD_FLEXIBILITY = 5;
	private SinglyLinkedList<SinglyLinkedList<String>> dictionary;
	
	/**
	 * constructor of Wordlist which stores the wordlist.txt into a dictionary
	 * which is a SinglyLinkedList of SinglyLinkedList of string stored in alphabetical order
	 * the running time of this method is O(n) where n is the size of the text
	 * @throws FileNotFoundException
	 */
	public WordList() throws FileNotFoundException {
		dictionary = new SinglyLinkedList<SinglyLinkedList<String>>();
		Scanner sc = new Scanner(new File(System.getProperty("user.dir")+"/wordlist.txt"));
		String check = "a";
		SinglyLinkedList<String> alphabet = new SinglyLinkedList<String>();
		while(sc.hasNextLine()) {
			String s = sc.nextLine();
			if(s.startsWith(check)) {
				alphabet.insert(s);
			}else {
				//if the string starts with a new character
				//store the previous linkedlist of strings and initialize a new one 
				//to store new words start with this char
				dictionary.insert(alphabet);
				check = ""+s.charAt(0);
				alphabet = new SinglyLinkedList<String>();
				alphabet.insert(s);
			}
		}
		dictionary.insert(alphabet);//add the last list of word start with z into the dictionary
	}
	/**
	 * Running time for this method is O(n)
	 * method to search for a new word in the wordlist 
	 * @param word
	 * @return newWord
	 */
	public String search(String word) {
		if(word.equals("")) {
			return null;
		}
		SinglyLinkedNode<SinglyLinkedList<String>> currList = dictionary.getHead();
		String firstOfLetter = currList.getData().getHead().getData();
		//go through the dictionary and get to the list with words starting with same character
		while(word.charAt(0)!=firstOfLetter.charAt(0)) {//O(26)
			currList= currList.getNext();
			firstOfLetter = currList.getData().getHead().getData();
		}
		SinglyLinkedNode<String> currWord = currList.getData().getHead();
		//go through the list and return the first word with edit distance > 5
		while(currWord!=null) {//O(n) n = number of words starting with specific character
			String check = currWord.getData();
			if(editDistance(check,word,check.length(),word.length())< WORD_FLEXIBILITY) {
				return check;
			}else {
				currWord = currWord.getNext();
			}
		}
		return null;
	}
	
	/**
	 * method to randomly pick 5 words from the wordlist and form a new sentence
	 * the running time is O(n)
	 * @return SinglyLinkedList of new sentence
	 */
	public SinglyLinkedList<String> pickFive(){
		int count = 0;
		SinglyLinkedList<String> newSentence = new SinglyLinkedList<String>();
		SinglyLinkedNode<SinglyLinkedList<String>> currList = dictionary.getHead();
		while(count<=5 && currList!=null) {//O(26)
			SinglyLinkedNode<String> currWord = currList.getData().getHead();
			while(count<=5 && currWord!=null) {//O(n) n = number of words starting with specific character
				if(Math.random()>0.5) {
					newSentence.insert(currWord.getData());
					count++;
				}
				currWord = currWord.getNext();
			}
			currList = currList.getNext();
		}
		return newSentence;
	}
	
	/**
	 * the running time is O(n)
	 * this is a recursive algorithm for finding the edit distance between two words
	 * @param word1
	 * @param word2
	 * @param l1
	 * @param l2
	 * @return the minimum editing distance between two words 
	 */
	public int editDistance(String word1,String word2,int l1,int l2) {
		//if one of the string is empty, the only option is to insert all characters of the other string
		if(l1==0) {//base case O(1)
			return l2;
		}
		if(l2==0) {
			return l1;
		}
		if(word1.charAt(l1-1)==word2.charAt(l2-1)) {
			return editDistance(word1,word2,l1-1,l2-1);//O(n-1)
		}else {
			int insert = editDistance(word1,word2,l1,l2-1);
			int delete = editDistance(word1,word2,l1-1,l2);
			int replace = editDistance(word1,word2,l1-1,l2-1);
			return 1+findMin(insert,delete,replace);
		}		
	}
	/**
	 * method to find the minimum value 
	 * running time is constant O(1)
	 * @param x
	 * @param y
	 * @param z
	 * @return minimum value among three inputs
	 */
	public int findMin(int x,int y,int z) {
		int min = x;
		if (y<=min) {
			min=y;
		}
		if(z<=min) {
			min=z;
		}
		return min;
	}
	
	
	
}