/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 * PA1 Part2
 */
package cs21.pa1.main;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TelephoneGame{
	public static WordList dictionary;
	public static SinglyLinkedList<People> people = new SinglyLinkedList<People>();
	public static SinglyLinkedList<String> sentence;
	public static SinglyLinkedList<String> hear ;
	public static SinglyLinkedList<String> speak = new SinglyLinkedList<String>();
	
	public static void main(String[] args) throws Exception {
		//set up the game and ask for an input sentence
		setUp();
		sentence = new SinglyLinkedList<String>();
		System.out.println("Please enter a sentence to start:");
		Scanner scanner = new Scanner(new Scanner(System.in).nextLine());
		String word;
		while(scanner.hasNext()){
			word = scanner.next();
			sentence.insert(word);
		}
		scanner.close();	
		SinglyLinkedNode<People> p = people.getHead();
		People first = p.getData();
		speak = sentence;
		while(p.getNext()!=null) {
			People next = p.getNext().getData();
			hear = new SinglyLinkedList<String>();
			System.out.println(first.getName()+" says "+"\""+speak.toString()+"\""+" to "+next.getName());
			double check = next.getSpeaking()*next.getListening();
			SinglyLinkedNode<String> currWord = speak.getHead();
			SinglyLinkedList<String> temp = new SinglyLinkedList<String>();
			int i = 0;
			while(i<speak.size()) {
				//for each word, the person has some probability to mishear it
				if(Math.random()>check) {
					//if mishear, get the word and drop up to three letters then find a new one
					String misheard = speak.remove(i).getData();
					speak.insert(misheard,i);
					//if the person mishear the word, use ___ to replace the word
					hear.insert("___");
					String newWord=dictionary.search(dropLetters(misheard));
					//if there's such new word, replace the old one with the new word, otherwise drop it
					if(newWord!=null) {
						speak.remove(i);
						speak.insert(newWord,i);
					}					
				}else {
					hear.insert(currWord.getData());
				}
				i++;
				currWord = currWord.getNext();
			}
			//if the sentence become empty, randomly pick 5 words from the word list
			if(speak.size()==0) {
				speak = dictionary.pickFive();
			}
			System.out.println(next.getName()+" hears "+"\""+hear.toString()+"\"");						
			p = p.getNext();
			first = next;
		}
		System.out.println(first.getName()+" says "+"\""+speak.toString()+"\"");
	}
	
	/**
	 * set up the game to have five people playing the game and set up the dictionary
	 * @throws FileNotFoundException
	 */
	public static void setUp() throws FileNotFoundException {		
		People p1 = new People("person1");
		People p2 = new People("person2");
		People p3 = new People("person3");
		People p4 = new People("person4");
		People p5 = new People("person5");
		people.insert(p1);
		people.insert(p2);
		people.insert(p3);
		people.insert(p4);
		people.insert(p5);
		dictionary = new WordList();
	}

	/**
	 * method to randomly drop up to three letters from the misheard word
	 * @param word
	 * @return
	 * running time for this method is O(n)
	 */
	public static String dropLetters(String word) {
		int drop = 0;
		String newWord = "";
		for(int i=0;i<word.length();i++) {
			if(drop<=3 && Math.random()>0.5) {
				drop++;
			}else {
				newWord+=word.charAt(i);
			}
		}
		return newWord;
	}
}