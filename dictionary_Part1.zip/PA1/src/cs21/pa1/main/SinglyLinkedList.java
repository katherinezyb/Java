/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 */
package cs21.pa1.main;

public class SinglyLinkedList<T> {
	
	private SinglyLinkedNode<T> head;
	private int size;
	
	public SinglyLinkedList(){
		this.head=null;
		this.size=0;
	}
	public SinglyLinkedNode<T> getHead(){//O(1)
		return head;
	}
	
	/**
	 * insert a new node at the end of the linkedlist
	 * if the list is empty, the new node will be the head
	 * Running time is O(n)
	 * @param data
	 */
	public void insert(T data){
		SinglyLinkedNode<T> newNode=new SinglyLinkedNode<T>(data);
		SinglyLinkedNode<T> curr=head;
		if(size==0) {
			head=newNode;
		}else {
			while(curr.getNext()!=null) {
				curr=curr.getNext();
			}
			curr.setNext(newNode);
		}
		size++;
	}
	
	/**
	 * remove the first node with data from the linkedlist
	 * if 
	 * the running time is O(n)
	 * @param data
	 */
	public void remove(T data) throws Exception{
		if (size==0) {
			System.out.println("error: list is empty");
		}else {
			SinglyLinkedNode<T> curr=head;
			SinglyLinkedNode<T> next=curr.getNext();
			if (head.getData().equals(data)){
				head=curr.getNext();
				size--;
			}else{
				while(next!=null) {
					if(next.getData().equals(data)) {
						curr.setNext(next.getNext());
						next = null;
						size--;
					}else {
						curr = next;
						next = next.getNext();
					}
				}		
			}
		}
	}
	public int size(){//O(1)
		return size;
	}
	public String toString(){//O(n)
		if (size==0){
			return "empty";
		}
		SinglyLinkedNode<T> curr=head;
		String s=head.toString();
		while (curr.getNext()!=null){
			curr=curr.getNext();
			s=s+", "+curr.toString();
		}
		return s;
	}
}

