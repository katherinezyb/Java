package cs21.pa1.test;
import cs21.pa1.main.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

public class PA1_part1_test{
	SinglyLinkedNode n1,n2,n3,n4;
	SinglyLinkedList l0,l1,l2;
	@BeforeAll
	public static void setUp() {
		System.out.println("Hello!");
	}
	
	@BeforeEach
	public void beforeEach() {
		n1 = new SinglyLinkedNode(1);
		n2 = new SinglyLinkedNode(2.5);
		n3 = new SinglyLinkedNode("3");
		n4 = new SinglyLinkedNode(true);
		l0 = new SinglyLinkedList();	
		l1 = new SinglyLinkedList();
		l2 = new SinglyLinkedList();
		l1.insert(100);
		l1.insert(3.1415);
		l1.insert("list1");
		l2.insert(0);
		
	}
	
	@AfterAll
	public static void end() {
		System.out.println("Goodbye.");
	}
	
	@Test
	public void testNodeData() {
		System.out.println("Checking for basic getting node data");
		assertEquals(1,n1.getData());
		assertEquals("1",n1.getData().toString());
		assertEquals(2.5,n2.getData());
		assertEquals("3",n3.getData());
		assertEquals(true,n4.getData());
		System.out.println("All tests passed!");
	}
	
	@Test
	public void testNode() {
		System.out.println("Checking for getting next node in the list");
		n1.setNext(n2);
		assertEquals(2.5,n1.getNext().getData());
		System.out.println("Test passed!");
	}
	
	@Test
	public void testLinkInfo() {
		System.out.println("Checking for methods of SinglyLinkedList");
		assertEquals(100,l1.getHead().getData());
		assertEquals(3,l1.size());
		assertEquals("100, 3.1415, list1",l1.toString());
		System.out.println("All tests passed!");
	}
	
	@Test
	public void testInsertAndRemove() throws Exception {
		System.out.println("Checking for Inserting and deleting of SinglyLinkedList");
		l1.insert(100);
		l1.insert("list1");
		l1.insert("new list1");
		l1.remove("list1");
		l1.remove(100);
		l1.remove(200);
		l2.remove(0);
		l0.insert("head");
		assertEquals(3.1415,l1.getHead().getData());
		assertEquals(4,l1.size());
		assertEquals("3.1415, 100, list1, new list1", l1.toString());
		assertEquals(null,l2.getHead());
		assertEquals("head",l0.getHead().getData());
		System.out.println("All tests passed!");
	}
	
	@Test
	public void testEdgeCases() throws Exception{
		System.out.println("Checking for edge cases");
		l0.remove(100);
		assertEquals(null,l0.getHead());
		assertEquals("empty",l0.toString());
		System.out.println("All tests passed!");
	}
}