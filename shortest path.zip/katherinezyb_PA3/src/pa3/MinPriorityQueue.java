/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 */
package pa3;

public class MinPriorityQueue {
	private int length;
	private GraphNode[] heapArray;
	private int heapSize;
	private HashMap map;
	
	
	public MinPriorityQueue(int size){
		length=size;
		heapArray=new GraphNode[size];
		heapSize=0;
		map=new HashMap(size);
	}
	/**
	 * insert GraphNode g into the queue with its priority
	 * @param g graphnode need to be inserted into the queue
	 */
	public void insert(GraphNode g){
		heapSize++;
		if(heapSize>=length-1) {
			GraphNode[] newheap = new GraphNode[length*2];
			for(int i=0;i<length;i++) {
				newheap[i]=heapArray[i];
			}
			heapArray=newheap;
			length=length*2;
		}
		map.set(g, heapSize);
		heapArray[heapSize]=g;
		heapifyUp(g);
	}
	/**
	 * return and remove the element with highest priority in the queue
	 * @return the element with Highest Priority in the queue
	 */
	public GraphNode pullHighestPriorityElement(){
		if (heapSize<1){
			throw new NullPointerException();
		}
		GraphNode g=heapArray[1];
		map.set(heapArray[1], -1);
		heapArray[1]=heapArray[heapSize];
		heapArray[heapSize]=null;
		heapSize--;
		heapifyDown(1);
		return g;
	}
	
	public void rebalance(GraphNode g){
		//use heapifyUp and heapifyDown instead
	}
	/**
	 * heapify up to restore the heap structure
	 * @param A the min priority queue that needs to restore heap structure
	 * @param index of the element that needs to be heapify up
	 */
	public void heapifyUp(GraphNode g){
		int i=map.getValue(g);
		while (i>1&&heapArray[i].priority<heapArray[i/2].priority){
			swap(i,i/2);
			i=i/2;
		}
	}
	/**
	 * heapify down 
	 * @param A the min priority queue
	 * @param value index of the element that needs to be heapify down
	 * @param heapSize to make sure we are not exceeding the size of the heap
	 */
	public void heapifyDown(int i){
		int l=2*i;
		int r=2*i+1;
		int smallest=0;
		if (l<=heapSize && heapArray[l].priority<heapArray[i].priority){
			smallest=l;
		}else{
			smallest=i;
		}
		if (r<=heapSize && heapArray[r].priority<heapArray[smallest].priority){
			smallest=r;
		}
		if (smallest!=i){
			swap(i,smallest);
			heapifyDown(smallest);
		}
	}
	/**
	 * swap two graphnodes
	 * @param index1 
	 * @param index2
	 */
	private void swap(int index1, int index2){
		GraphNode temp=heapArray[index1];//store one node in temp
		heapArray[index1]=heapArray[index2];
		map.set(heapArray[index1],index1);
		heapArray[index2]=temp;
		map.set(temp, index2);
	}
	
	public boolean isEmpty(){
		if (heapSize==0){
			return true;
		}else{
			return false;
		}
	}
	//if update the priority, re-store the property by heapifyUp
	public void decreaseP(GraphNode g, int newP){
		g.priority=newP;
		heapifyUp(g);
	}
	
	public boolean inQueue(GraphNode g){
		return map.hasKey(g);
	}
	
}
