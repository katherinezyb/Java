/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 */
package pa3;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class FindMinPath {
	public static String output="";
	public static MinPriorityQueue Q;
	public static void main(String[] args) throws IOException{
		//create a priority queue Q
		Q=new MinPriorityQueue(1000000);
		//get the GraphNode for home and set priority to 0
		GraphWrapper gw=new GraphWrapper();
		GraphNode home=gw.getHome();
		home.priority=0;
		GraphNode goal=null;
		Q.insert(home);
		while (!Q.isEmpty()&& goal==null){//while haven't found the goal
			GraphNode curr=Q.pullHighestPriorityElement();
			if (curr.isGoalNode()){
				goal=curr;
			}else {
				//check each neighbor
				if (curr.hasEast()){
					int x=curr.priority+curr.getEastWeight();
					checkNeighbor(curr, curr.getEast(), x, "East");
				}
				if (curr.hasNorth()){
					int x=curr.priority+curr.getNorthWeight();
					checkNeighbor(curr, curr.getNorth(), x, "North");
				}
				if (curr.hasSouth()){
					int x=curr.priority+curr.getSouthWeight();
					checkNeighbor(curr, curr.getSouth(), x, "South");
				}
				if (curr.hasWest()){
					int x=curr.priority+curr.getWestWeight();
					checkNeighbor(curr, curr.getWest(), x, "West");
				}
			}				
		}
		
		FileWriter fileWriter=new FileWriter("answer.txt");
		PrintWriter pw=new PrintWriter(fileWriter);
		if (Q.isEmpty()&&goal==null){
			pw.println("No path found");
		}else{
			GraphNode temp=goal;
			String[] route=new String[1000];
			int i=999;
			while (!(temp.equals(home))&& i>=0){
				route[i]=temp.previousDirection;
				temp=temp.previousNode;
				i--;
			}
			for (int j=i+1;j<route.length;j++){
				pw.println(route[j]);
			}
		}
		pw.close();
	}
	/**
	 * check surrounding nodes, update their priority
	 * @param Q the minpriority queue
	 * @param curr 
	 * @param neighbor 
	 * @param x
	 * @param direction string of the direction
	 */
	public static void checkNeighbor(GraphNode curr, GraphNode neighbor, int x, String direction){
		if (!Q.inQueue(neighbor)&& neighbor.previousNode==null){
			neighbor.priority=x;
			neighbor.previousNode=curr;
			neighbor.previousDirection=direction;
			Q.insert(neighbor);
		}else{
			if (x<neighbor.priority){
				Q.decreaseP(neighbor,x);
				neighbor.previousNode=curr;
				neighbor.previousDirection=direction;
			}
		}
	}
	/**
	 * for junit tesing
	 * @param gw
	 * @param home
	 * @return output string that is the same as content in the file if run the main
	 * @throws IOException
	 */
	public String run(GraphWrapper gw,GraphNode home) throws IOException {
		Q=new MinPriorityQueue(1000000);
		home.priority=0;
		GraphNode goal=null;
		Q.insert(home);
		while (!Q.isEmpty()&& goal==null){//while haven't found the goal
			GraphNode curr=Q.pullHighestPriorityElement();
			if (curr.isGoalNode()){
				goal=curr;
			}else {
				//check each neighbor
				if (curr.hasEast()){
					int x=curr.priority+curr.getEastWeight();
					checkNeighbor(curr, curr.getEast(), x, "East");
				}
				if (curr.hasNorth()){
					int x=curr.priority+curr.getNorthWeight();
					checkNeighbor(curr, curr.getNorth(), x, "North");
				}
				if (curr.hasSouth()){
					int x=curr.priority+curr.getSouthWeight();
					checkNeighbor(curr, curr.getSouth(), x, "South");
				}
				if (curr.hasWest()){
					int x=curr.priority+curr.getWestWeight();
					checkNeighbor(curr, curr.getWest(), x, "West");
				}
			}				
		}
		if (Q.isEmpty()&&goal==null){
			output+="No path found\n";
		}else{
			GraphNode temp=goal;
			String[] route=new String[1000];
			int i=999;
			while (!(temp.equals(home))&& i>=0){
				route[i]=temp.previousDirection;
				temp=temp.previousNode;
				i--;
			}
			for (int j=i+1;j<route.length;j++){
				output+=route[j]+"\n";
			}
		}
		return output;
	}
	
}
