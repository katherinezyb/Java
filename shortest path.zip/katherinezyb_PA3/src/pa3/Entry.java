/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 */
package pa3;

public class Entry {
	public GraphNode key;
	public int value;
	
	public Entry (GraphNode key, int value){
		this.key=key;
		this.value=value;
	}
}
