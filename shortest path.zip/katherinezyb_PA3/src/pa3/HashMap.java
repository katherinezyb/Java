/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 */

package pa3;

public class HashMap{
	public Entry[] hashTable;
	public int size;
	public int totalElement;
	
	public HashMap(int size) {
		this.size = size;
		hashTable = new Entry[size];
		totalElement=0;
		
	}
	
	public void set(GraphNode key, int value) {
		if(totalElement/size >= 0.5) {//rehashing if load factor greater than 0.5
			rehashing();
		}
		int index = hashing(key,size);
		//if there's key in the table, update the value
		if(hashTable[index]!=null) {
			if(hashTable[index].key.equals(key)) {
				hashTable[index].value = value;
			}			
		}else {//if not in the table, insert it
			hashTable[index]=new Entry(key,value);
			totalElement++;
		}
	}
	//get value for the entry with graphnode g
	public int getValue(GraphNode g) {
		int index = hashing(g,size);
		return hashTable[index].value;
	}
	
	public boolean hasKey(GraphNode g) {
		int index = hashing(g,size);
		if(hashTable[index]!=null && hashTable[index].value!=-1) {
			return true;
		}
		return false;
	}
	
	public int hashing(GraphNode g,int sizeOfTable) {
		String id = g.getId();
		id = id.substring(0,9);
		String s="";
		//use integers in the first 8 characters
		for(int i=0;i<8;i++) {
			if(Character.isDigit(id.charAt(i))) {
				s+=id.charAt(i);
			}
		}
		//handle exception: if there's no integer in the first 8, use last 8
		if(s.length()==0) {
			id = g.getId().substring(26);
			for(int i=0;i<8;i++) {
				if(Character.isDigit(id.charAt(i))) {
					s+=id.charAt(i);
				}
			}			
		}
		int index = Integer.parseInt(s)%sizeOfTable;
		//handle collison
		int i=0;
		while(hashTable[index]!=null && !hashTable[index].key.equals(g)) {
			i++;
			index=(index+i*i)%sizeOfTable;
		}
		return index;
	}
	
	//copy everything in the old table to the new table with double size
	public void rehashing() {
		Entry[] newHashTable = new Entry[size*2];
		for(int i=0;i<size;i++) {
			if(hashTable[i]!=null) {
				//get the old index and calculate the new index in the new table
				int index = hashing(hashTable[i].key,size*2);
				newHashTable[index]=hashTable[i];
			}
		}
		hashTable = newHashTable;
		size=size*2;
	}
}
