package test;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.junit.jupiter.api.*;

import pa3.FindMinPath;
import pa3.GraphNode;
import pa3.GraphWrapper;

public class FindPathTest{
	@Test
	public void test0011() throws IOException {
		FindMinPath mp = new FindMinPath();
		GraphWrapper gw = new GraphWrapper(true);
		GraphNode home = gw.getHome();
		assertEquals("South\nEast\n",mp.run(gw,home));			
	}
	
	@Test
	public void test14273216() throws IOException {
		FindMinPath mp = new FindMinPath();
		GraphWrapper gw = new GraphWrapper(true);
		GraphNode home = gw.getHome();
		assertEquals("East\n" + 
				"North\n" + 
				"North\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"North\n" + 
				"North\n" + 
				"North\n" + 
				"North\n" + 
				"North\n" + 
				"North\n" + 
				"North\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"North\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"North\n" + 
				"East\n" + 
				"North\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"South\n" + 
				"East",mp.run(gw,home).trim());
	}
	
	@Test
	public void test45235663() throws IOException {
		FindMinPath mp = new FindMinPath();
		GraphWrapper gw = new GraphWrapper(true);
		GraphNode home = gw.getHome();
		assertEquals("East\n" + 
				"South\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"South\n" + 
				"South\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"East\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"East\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"East\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"West\n" + 
				"South\n" + 
				"West\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"East\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"East\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"East\n" + 
				"South\n" + 
				"South\n" + 
				"East\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"South\n" + 
				"East\n" + 
				"South\n" + 
				"East\n" + 
				"South\n" + 
				"East\n" + 
				"South\n" + 
				"West\n" + 
				"South\n" + 
				"South\n" + 
				"West\n" + 
				"West\n" + 
				"West\n" + 
				"South",mp.run(gw,home).trim());
	}
}