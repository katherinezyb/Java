package test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import pa3.GraphNode;
import pa3.MinPriorityQueue;

public class PriorityQueueTest{
	GraphNode g1 = new GraphNode("0fd76b04-1df7-4838-b854-e270f42a5dd6",true);
	GraphNode g2 = new GraphNode("d23343d2-bc99-4145-a833-dd8e9b0dd356",true);
	GraphNode g3 = new GraphNode("d76ed44b-6c4f-40db-a605-a19210f64f7d",true);
	GraphNode g4 = new GraphNode("fedf90fe-7e00-4155-93d6-b3d2e612f737",true);
	MinPriorityQueue Q = new MinPriorityQueue(10);
	
	@Test
	public void testInsertAndPull() {
		g1.priority=1;
		g2.priority=2;
		Q.insert(g2);
		Q.insert(g1);
		assertEquals(g1,Q.pullHighestPriorityElement());
	}
	@Test
	public void testDecreaseP() {
		g1.priority=6;
		g2.priority=4;
		g3.priority=3;
		Q.insert(g1);
		Q.insert(g2);
		Q.insert(g3);
		Q.decreaseP(g2, 1);
		assertEquals(g2,Q.pullHighestPriorityElement());
	}
}

