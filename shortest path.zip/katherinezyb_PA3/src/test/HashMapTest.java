/**
 * Katherine Zhu
 * katherinezyb@brandeis.edu
 */
package test;

import static org.junit.Assert.*;
import org.junit.Test;

import pa3.GraphNode;
import pa3.HashMap;


public class HashMapTest{
	GraphNode g1 = new GraphNode("0fd76b04-1df7-4838-b854-e270f42a5dd6",true);
	GraphNode g2 = new GraphNode("d23343d2-bc99-4145-a833-dd8e9b0dd356",true);
	GraphNode g3 = new GraphNode("d76ed44b-6c4f-40db-a605-a19210f64f7d",true);
	GraphNode g4 = new GraphNode("fedf90fe-7e00-4155-93d6-b3d2e612f737",true);
	HashMap testmap = new HashMap(10);
	
	@Test
	public void testHashing() {		
		testmap.set(g1, 1);
		int index = testmap.hashing(g3,10);
		assertEquals(5,index);
	}
	@Test
	public void testSet() {		
		testmap.set(g1, 1);
		testmap.set(g2, 2);
		testmap.set(g3, 3);
		testmap.set(g4, 4);
		assertEquals(4,testmap.totalElement);
	}
	@Test
	public void testgetvalue() {
		testmap.set(g1, 1);
		assertEquals(1,testmap.getValue(g1));
	}
	@Test
	public void testHaskey() {
		testmap.set(g1, 1);
		assertTrue(testmap.hasKey(g1));
	}
}