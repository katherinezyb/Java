package pa2.SPL_DIGITAL_LIB;

public class SplayTreeUtils {
	
	/**
	 * zig performs a right rotation 
	 * O(1)
	 * @param node 
	 */
	public static void zig(SplayTreeNode node) {
		SplayTreeNode v = node.parent;//get the parent node
		SplayTreeNode y = v.left;//current node
		v.left = y.right;//moves current node's right child to be its parent's left child
		if(y.right!=null) {
			y.right.parent = v;//connect to the new parent
		}
		y.parent=v.parent;//move current node to its parent's position
		if(v.parent!=null) {
			if(v==v.parent.right) {
				v.parent.right=y;
			}else {
				v.parent.left=y;
			}
		}
		y.right=v;
		v.parent=y;
	}
	
	/**
	 * zag performs a left rotation 
	 * O(1)
	 * @param node 
	 */
	public static void zag(SplayTreeNode node) {
		SplayTreeNode v = node.parent;//get the parent node
		SplayTreeNode y = v.right;//current node
		v.right=y.left;//moves current node's left child to be its parent's right child
		if(y.left!=null) {
			y.left.parent = v;
		}
		y.parent = v.parent;//move current node to its parent's position
		if(v.parent!=null) {
			if(v.equals(v.parent.left)) {
				v.parent.left=y;
			}else {
				v.parent.right=y;
			}
		}
		y.left=v;
		v.parent=y;
	}
	/**
	 * this method insert a new node into the splay tree: find a place to insert then splay it to the root
	 * insertion only takes O(1) but with finding and splaying, running time will be O(logn)
	 * @param root
	 * @param newNode
	 * @param mode
	 */
	public static void insert(SplayTreeNode root, SplayTreeNode newNode, int mode) {
		SplayTreeNode v=root;
    	SplayTreeNode temp=v;
    	if(mode == 0) {
    		while (temp!=null){//keep comparing with other nodes going down the tree
        		v=temp;
        		if (((Book) temp.data).compareTo((Book) newNode.data)<0){
        			temp=temp.right;
        		}else{
        			temp=temp.left;
        		}
        	}
        	newNode.parent=v;
        	if (((Book) newNode.data).compareTo((Book) v.data)<0){
        		v.left=newNode;
        	}else{
        		v.right=newNode;
        	}
        	splay(newNode);//then splay the newnode to the root
    	}else {
    		while (temp!=null){//keep comparing with other nodes going down the tree
        		v=temp;
        		if (((Book) temp.data).ISBN < ((Book) newNode.data).ISBN){
        			temp=temp.right;
        		}else{
        			temp=temp.left;
        		}
        	}
        	newNode.parent=v;
        	if (((Book) newNode.data).ISBN < ((Book) v.data).ISBN){
        		v.left=newNode;
        	}else{
        		v.right=newNode;
        	}
        	splay(newNode);//then splay the newnode to the root
    	}
	}
	/**
	 * this method delete a node from the tree: search the node first, if found, splay to root then delete it
	 * connect two subtrees
	 * deletion only takes O(1) but have to find the node first 
	 * the Running time is O(logn)
	 * @param root
	 * @param node
	 * @param mode
	 * @return
	 */
	public static SplayTreeNode delete(SplayTreeNode root, SplayTreeNode node,int mode) {
		SplayTreeNode v = search(root,node,mode);//first find it and splay it to root	
		if(v==null) {//if can't find such node in the tree, just return the current root
			return root;
		}
		//store the left and right subtrees
		SplayTreeNode leftSubTree = v.left;
		SplayTreeNode rightSubTree = v.right;
		//delete the node
		v.left=null;
		v.right=null;
		v=null;
		//left subtree is empty, then return the right subtree
		if(leftSubTree==null) {
			if(rightSubTree!=null) {
				rightSubTree.parent=null;
			}
			return rightSubTree;
		}else {
			leftSubTree.parent=null;
			//find the predecessor of the old root then splay it to the root of left subtree
			SplayTreeNode w = findRightmost(leftSubTree);
			splay(w);
			w.right=rightSubTree;//attach the right subtree to this new root
			rightSubTree.parent=w;
			return w;
		}
	}
	//O(h)
	public static SplayTreeNode findRightmost(SplayTreeNode node) {
		SplayTreeNode v = node;
		while(v.right!=null) {
			v=v.right;
		}
		return v;
	}
	
	//O(logn) return the new root after searching for a node
	public static SplayTreeNode search(SplayTreeNode root, SplayTreeNode searchItem, int mode) {
		SplayTreeNode v = findNode(root,searchItem,mode);
		if(v==null) {
			return null;
		}
		splay(v);
		return v;
	}
	/**
	 * running time is O(logn)
	 * this method used to find the node with some data in the tree and return it
	 * @param root
	 * @param searchItem
	 * @param mode
	 * @return the node with data which the same as the one searched or the last one visited
	 */
	public static SplayTreeNode findNode(SplayTreeNode root, SplayTreeNode searchItem, int mode) {
		SplayTreeNode v = root;
		SplayTreeNode w;
		if(v==null) {
			return null;
		}
		if(mode==0) {//compare by author
			String author = (String)searchItem.data;
			if(((Book)v.data).author.equals(author)){
				return v;
			}
			if(author.compareTo(((Book) v.data).author)<0) {
				return findNode(v.left,searchItem,0);
			}else {
				return findNode(v.right,searchItem,0);
			}
		}else {
			long isbn = (long)searchItem.data;
			if(((Book)v.data).ISBN==isbn){
				return v;
			}
			if(isbn < ((Book)v.data).ISBN) {
				return findNode(v.left,searchItem,1);
			}else {
				return findNode(v.right,searchItem,1);
			}
		}
	}
	/**
	 * this method splay the tree node to the root
	 * running time O(logn)
	 * worst case running time is O(n) if the tree is highly unbalanced
	 * @param node
	 */
	public static void splay(SplayTreeNode node) {
		SplayTreeNode v = node;
		while(v.parent!=null) {//the node doesn't become the root
			SplayTreeNode p = v.parent;
			SplayTreeNode g = p.parent;
			if(g!=null) {//4 conditions with parent and grandparent
				if(p==g.left && v==p.left) {
					zig(p);
					zig(v);
				}else if((p==g.right && v==p.right)) {
					zag(p);
					zag(v);
				}else if((p==g.left && v==p.right)) {
					zag(v);
					zig(v);
				}else if((p==g.right && v==p.left)){
					zig(v);
					zag(v);
				}
			}else {//if the node is one step away from the root, do a single rotation
				if(v==p.left) {
					zig(v);
				}else {
					zag(v);
				}
			}
		}
	}
	
}