package pa2.SPL_DIGITAL_LIB;

public class SplayTreeNode<T>{
	public T data;
	public SplayTreeNode<T> left;
	public SplayTreeNode<T> right;
	public SplayTreeNode<T> parent;
	
	public SplayTreeNode() {
		
	}
	public SplayTreeNode(T data) {
		this.data = data;
	}
	public String toString() {
		String s = data.toString()+"\n";
		s+="LEFT    |    ";
		if(this.left == null) {
			s+="NULL\n";
		}else {
			s+=left.data.toString()+"\n";
		}
		s+="RIGHT   |    ";
		if(this.right == null) {
			s+="NULL";
		}else {
			s+=right.data.toString();
		}
		return s;
	}
}