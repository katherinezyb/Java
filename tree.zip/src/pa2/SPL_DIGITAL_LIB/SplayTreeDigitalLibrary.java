package pa2.SPL_DIGITAL_LIB;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class SplayTreeDigitalLibrary {
	public static String output;
	public static Scanner console;
	public static SplayTreeNode<Book> rootB = null;
	public static SplayTreeNode<Book> rootA = null;
	public static SplayTreeNode<Book> rootI = null;
	public static File authorTree = new File(System.getProperty("user.dir")+"/pa2/SPL_DIGITAL_LIB/spltree_digi_lib_auth.txt");
	public static File isbnTree = new File(System.getProperty("user.dir")+"/pa2/SPL_DIGITAL_LIB/spltree_digi_lib_isbn.txt");
	public static File borrowTree = new File(System.getProperty("user.dir")+"/pa2/SPL_DIGITAL_LIB/spltree_digi_lib_borrowed.txt");

	public String main(String[] args) {
		output="";
		Scanner scanner=null;
		output+="Welcome to the SPLTREE_DIGITAL_LIBRARY.\nLoading library...  ";
		System.out.print("Welcome to the SPLTREE_DIGITAL_LIBRARY.\nLoading library...  ");
		if(authorTree.exists() && isbnTree.exists() && borrowTree.exists()) {
			rootA = returnToTree(authorTree);
			rootI = returnToTree(isbnTree);
			rootB = returnToTree(borrowTree);
		}else{
			try {
				scanner = new Scanner(new File(System.getProperty("user.dir")+"/pa2/SPL_DIGITAL_LIB/spltree_digi_lib_baselib.txt"));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//get the first book and set it to be root of both trees
			String book = scanner.nextLine();
			String[] info = book.split("\t");
			String title = info[0];
			String author = info[1];
			String isbnString = info[2];
			long isbn = Long.parseLong(isbnString);
			rootA = new SplayTreeNode<Book>(new Book(title,author,isbn));
			rootI = new SplayTreeNode<Book>(new Book(title,author,isbn));
			while(scanner.hasNext()) {
				book = scanner.nextLine();
				info = book.split("\t");
				if(info.length==3) {
					title = info[0].trim();
					author = info[1].trim();
					isbnString = info[2].trim();
					isbn = Long.parseLong(isbnString);
					SplayTreeNode<Book> nodeA = new SplayTreeNode<Book>(new Book(title,author,isbn));
					SplayTreeNode<Book> nodeI = new SplayTreeNode<Book>(new Book(title,author,isbn));
					SplayTreeUtils.insert(rootA, nodeA, 0);
					SplayTreeUtils.insert(rootI, nodeI, 1);
					rootA = nodeA;
					rootI = nodeI;
				}
			}
			writeToFile(authorTree,rootA);
			writeToFile(isbnTree,rootI);
			writeToFile(borrowTree,rootB);
		}
		output+="DONE.\n\n";
		System.out.println("DONE.\n");
		String input;
		do {
			console = new Scanner(System.in);
			output+="Please enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: ";
			System.out.println("Please enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: ");
			input = console.nextLine();
			output+=input+"\n";
			if(input.equalsIgnoreCase("author")) {
				searchByType(rootA,0);
			}else if(input.equalsIgnoreCase("isbn")) {
				searchByType(rootI,1);
			}else if(input.equalsIgnoreCase("return")) {//rewrite all three files if a book returned
				rootB = returnBook();
				writeToFile(authorTree,rootA);
				writeToFile(isbnTree,rootI);
				writeToFile(borrowTree,rootB);
			}else if(input.equalsIgnoreCase("popular")) {//gives the top book of author tree and isbn tree
				output+=(rootA.data.toString()+"\n"+rootI.data.toString()+"\n\n");
				System.out.println(rootA.data.toString()+"\n"+rootI.data.toString()+"\n");
			}
		}while(!input.equalsIgnoreCase("exit"));
		return output.trim(); // You MUST return all output to the console here
	}
	
	/**
	 * this method search the tree based on your information
	 * rewrite the text file if the node found
	 * Running time is searching O(logn) + writing file O(n)
	 * @param root
	 * @param mode
	 */
	public static void searchByType(SplayTreeNode root, int mode) {
		SplayTreeNode search;
		SplayTreeNode v;
		if(mode == 0) {
			output+="You have selected Search by Author. Please enter the author name: ";
			System.out.print("You have selected Search by Author. Please enter the author name: ");
			String author = console.nextLine();
			output+=author+"\n";
			search = new SplayTreeNode(author);
			v = SplayTreeUtils.search(root, search, mode);
			rootA = v;
			if(v!=null) {
				writeToFile(authorTree,rootA);
			}
		}else {
			output+="You have selected Search by ISBN. Please enter the ISBN: ";
			System.out.print("You have selected Search by ISBN. Please enter the ISBN: ");
			long isbn = console.nextLong();
			output+=isbn+"\n";
			search = new SplayTreeNode(isbn);
			v = SplayTreeUtils.search(root, search, mode);
			rootI = v;
			if(v!=null) {
				writeToFile(isbnTree,rootI);
			}
		}
		askForBorrow(v);
	}
	/**
	 * this method ask whether you want to borrow the book
	 * Running time  = deletion O(logn) + rewrite the text file O(n)
	 * @param v
	 */
	public static void askForBorrow(SplayTreeNode<Book> v) {
		if(v==null) {
			output+="Sorry, no books were found with your search term.\n\n";
			System.out.println("Sorry, no books were found with your search term.\n");
		}else {
			output+="The following entry matched your search term:\n"+v.data.toString()+"\n\n";
			System.out.println("The following entry matched your search term: \n"+v.data.toString()+"\n");
			String s;
			do {
				console=new Scanner(System.in);
				output+="Would you like to borrow this book? (y/n) ";
				System.out.print("Would you like to borrow this book? (y/n) ");
				s = console.nextLine();
				output+=s+"\n\n";
			}while(!(s.equals("y")||s.equals("n")));
			if(s.equals("y")) {
				borrowBook(new SplayTreeNode(v.data));
				writeToFile(borrowTree,rootB);
				SplayTreeNode toDeleteA = new SplayTreeNode(((Book)v.data).author);
				SplayTreeNode toDeleteI = new SplayTreeNode(((Book)v.data).ISBN);
				rootA = SplayTreeUtils.delete(rootA, toDeleteA, 0);
				rootI = SplayTreeUtils.delete(rootI, toDeleteI, 1);
				writeToFile(authorTree,rootA);
				writeToFile(isbnTree,rootI);
			}
		}
	}
	public static void borrowBook(SplayTreeNode<Book> node) {
		if(rootB == null) {
			rootB = node;
		}else {
			SplayTreeUtils.insert(rootB, node, 0);
			rootB = node;
		}
	}
	/**
	 * This method returns a book: find the book with the author provided
	 * if found, delete if from borrow tree and insert it back into both author tree and isbn tree for further reading
	 * Running time is insertion + deletion = O(logn)
	 * @return
	 */
	public static SplayTreeNode<Book> returnBook() {
		output+="Please enter the author for the book you are returning: ";
		System.out.print("Please enter the author for the book you are returning: ");
		String author = console.nextLine();
		output+=author+"\n";
		SplayTreeNode<Book> v = SplayTreeUtils.search(rootB, new SplayTreeNode<String>(author), 0);
		if(v==null) {//if can't find the book in the borrow the return the origin root of borrow tree
			output+="Sorry, no books were borrowed with that author.\n\n";
			System.out.println("Sorry, no books were borrowed with that author.");
			return rootB;
		}else {
			SplayTreeNode duplicate = new SplayTreeNode(v.data);
			SplayTreeNode duplicate2 = new SplayTreeNode(v.data);
			output+="Thank you for returning this book.\n\n";
			System.out.println("Thank you for returning this book.\n");
			//put book back in both authorTree and ISBNtree
			SplayTreeUtils.insert(rootA, duplicate, 0);			
			SplayTreeUtils.insert(rootI,duplicate2, 1);
			rootA = duplicate;
			rootI = duplicate2;
			//return the new root of borrow tree after deletion
			SplayTreeNode toDelete = new SplayTreeNode(((Book)v.data).author);//search and delete only by author
			v = SplayTreeUtils.delete(v, toDelete, 0);
			return v;
		}
	}
	//O(n)
	public static void writeToFile(File f,SplayTreeNode node) {
		if(!f.exists()) {
			try {
				f.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		FileWriter fw;
		try {
			fw = new FileWriter(f.getAbsolutePath(),false);
			serialize(fw,node);
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	/**
	 * recursive method for print the tree in preorder into file
	 * running time is O(n)
	 * @param fw
	 * @param node
	 */
	public static void serialize(FileWriter fw, SplayTreeNode node) {
		try {
			if(node == null) {
				fw.write("-1\n");
			}else {
				fw.write(node.data.toString()+"\n");
				serialize(fw,node.left);
				serialize(fw,node.right);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * if the file contains item other than "-1", it must be a root since I print the tree in preorder
	 * so when get back, get the first one to be the root then go recursive deserialization
	 * running time is O(n)
	 * @param f
	 * @return
	 */
	public static SplayTreeNode returnToTree(File f) {
		SplayTreeNode<Book> node = null;
		try {
			Scanner scanner = new Scanner(f);
			if(scanner.hasNext()) {
				String item = scanner.nextLine();
				if(!item.equals("-1")) {
					String[] info = item.split(", ");
					if(info.length>3) {
						info = handleInconsis(info);
					}
					node = new SplayTreeNode<Book>(new Book(info[0],info[1],Long.parseLong(info[2])));
				}
				if(node!=null) {
					deserialize(node,scanner);
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return node;
	}
	/**
	 * recursive method to return the preorder traversal of tree back into a tree
	 * running time O(n)
	 * @param root
	 * @param scanner
	 */
	public static void deserialize(SplayTreeNode root, Scanner scanner) {
		int count = 0;//only for getting out of the loop
		while(scanner.hasNext()&&count<2) {
			String item = scanner.nextLine();
			//connect the left child first
			if(item.equals("-1")) {
				//root.left = null;
				count++;
			}else{
				String[] info = item.split(", ");
				if(info.length>3) {
					info = handleInconsis(info);
				}
				SplayTreeNode<Book> node = new SplayTreeNode<Book>(new Book(info[0],info[1],Long.parseLong(info[2])));
				node.parent=root;
				
				if(root!=null) {
					root.left = node;
				}
				deserialize(node,scanner);
				count++;
			}
			//then connect right child
			item = scanner.nextLine();
			if(item.equals("-1")) {
				//root.right = null;
				count++;
			}else{
				String[] info = item.split(", ");
				if(info.length>3) {
					info = handleInconsis(info);
				}
				SplayTreeNode<Book> node = new SplayTreeNode<Book>(new Book(info[0],info[1],Long.parseLong(info[2])));
				node.parent=root;
				
				if(root!=null) {
					root.right = node;
				}
				deserialize(node,scanner);
				count++;
			}
		}
	}
	//O(n) for handling inconsistency in book items like ","
	public static String[] handleInconsis(String[] info) {
		String number = info[info.length-1];
		String name = info[info.length-2];
		String bookname = "";
		for(int i=0;i<info.length-3;i++) {
			bookname=bookname+info[i]+", ";
		}
		bookname+=info[info.length-3];
		info[0]=bookname;
		info[1]=name;
		info[2]=number;
		return info;
	}
}
