package pa2.SPL_DIGITAL_LIB;

public class Book implements Comparable<Book>{
	public String title;
	public String author;
	public long ISBN;
	
	public Book(String title, String author, long ISBN) {
		this.title=title;
		this.author=author;
		this.ISBN=ISBN;
	}
	
	public String toString() {
		return title+", "+author+", "+Long.toString(ISBN);
	}
	@Override
	public int compareTo(Book b) {
		// TODO Auto-generated method stub
		return this.author.compareTo(b.author);
	}
}
