package pa2.testSuite;

import pa2.SPL_DIGITAL_LIB.*;

import static org.junit.Assert.*;

import org.junit.Test;

public class SplayTreeDigitalLibraryTests {

	@Test
	public void testPopular() {
		SplayTreeDigitalLibrary digilib = new SplayTreeDigitalLibrary();
		String[] args = {"author", "Keith Cooper & Linda Torczon", "n", "isbn", "9780262640688", "n", "exit"};
		digilib.main(args);

		SplayTreeDigitalLibrary digilib2 = new SplayTreeDigitalLibrary();
		String[] args2 = {"popular", "exit"};
		String output = digilib2.main(args2);

		String expectedOutput = "Welcome to the SPLTREE_DIGITAL_LIBRARY.\nLoading library...  DONE.\n\nPlease enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: popular\nEngineering: A Compiler, 2nd Edition, Keith Cooper & Linda Torczon, 9780120884780\nThe Elements of Computing Systems: Building a Modern Computer from First Principles, Noam Nisan & Shimon Schocken, 9780262640688\n\nPlease enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: exit";
		System.out.print(output);
		assertTrue(output.equals(expectedOutput));
		
	}
	@Test
	public void testBorrow() {
		SplayTreeDigitalLibrary digilib = new SplayTreeDigitalLibrary();
		String[] args = {"author", "Keith Cooper & Linda Torczon","y","isbn","9780120884780","exit"};
		String output = digilib.main(args);
		String expectedOutput = "Welcome to the SPLTREE_DIGITAL_LIBRARY.\nLoading library...  DONE.\n\nPlease enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: author\nYou have selected Search by Author. Please enter the author name: "
								+"Keith Cooper & Linda Torczon\nThe following entry matched your search term:\nEngineering: A Compiler, 2nd Edition, Keith Cooper & Linda Torczon, 9780120884780\n\nWould you like to borrow this book? (y/n) y\n\n"
								+"Please enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: isbn\nYou have selected Search by ISBN. Please enter the ISBN: 9780120884780\n"
								+"Sorry, no books were found with your search term.\n\nPlease enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: exit";
		assertTrue(output.equals(expectedOutput));//check delete
	}
	@Test
	public void testReturn() {
		SplayTreeDigitalLibrary digilib1 = new SplayTreeDigitalLibrary();
		String[] args1 = {"return", "Keith Cooper & Linda Torczon","exit"};
		String output = digilib1.main(args1);
		String expectedOutput = "Welcome to the SPLTREE_DIGITAL_LIBRARY.\nLoading library...  DONE.\n\nPlease enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: return\nPlease enter the author for the book you are returning: Keith Cooper & Linda Torczon\nThank you for returning this book.\n\n"
								+"Please enter ‘author’ to search by author name, ‘ISBN’ to search by " + 
								"reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, " + 
								"or ‘exit’ to leave the program: exit";
		assertTrue(output.equals(expectedOutput));//check in borrow
		
		SplayTreeDigitalLibrary digilib2 = new SplayTreeDigitalLibrary();
		String[] args2 = {"popular","exit"};
		String output2 = digilib2.main(args2);
		String expectedOutput2 = "Welcome to the SPLTREE_DIGITAL_LIBRARY.\nLoading library...  DONE.\n\nPlease enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: popular\nEngineering: A Compiler, 2nd Edition, Keith Cooper & Linda Torczon, 9780120884780\nEngineering: A Compiler, 2nd Edition, Keith Cooper & Linda Torczon, 9780120884780\n\nPlease enter ‘author’ to search by author name, ‘ISBN’ to search by reference ISBN, ‘popular’ to see the top books, ‘return’ to return a book, or ‘exit’ to leave the program: exit";
		assertTrue(output2.equals(expectedOutput2));//check inserting back
	}
	
}